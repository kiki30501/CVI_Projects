#include <advanlys.h>
#include <ansi_c.h>
#include <cvirte.h>		
#include <userint.h>
#include "lab2.h"



static int panelHandle;
double dt, Time = 0;
double q1, q2, q3, q4;
double c1, c2, c3, c4, v1, v2, v3, v4, cu1, cu2;
double r, r13, r14, r23, r24, r34, i, i13, i14, i23, i24, i34;


 // Define the resistance matrix (1/R values)
   

    // Current vector to store results
    double Ivec[6];

void GetGlobalVal ()
{
	GetCtrlVal (panelHandle, PANEL_Voltage, &v1);
	GetCtrlVal (panelHandle, PANEL_Voltage_2, &v2);
	GetCtrlVal (panelHandle, PANEL_Voltage_3, &v3);
	GetCtrlVal (panelHandle, PANEL_Voltage_4, &v4);
	
	GetCtrlVal (panelHandle, PANEL_Capacitance, &c1);
	GetCtrlVal (panelHandle, PANEL_Capacitance_2, &c2);
	GetCtrlVal (panelHandle, PANEL_Capacitance_3, &c3);
	GetCtrlVal (panelHandle, PANEL_Capacitance_4, &c4);
	
	GetCtrlVal (panelHandle, PANEL_Current_in, &cu1);
	GetCtrlVal (panelHandle, PANEL_Current_in_2, &cu2);
	GetCtrlVal (panelHandle, PANEL_Resistance, &r);
	GetCtrlVal (panelHandle, PANEL_Resistance_2, &r13);
	GetCtrlVal (panelHandle, PANEL_Resistance_3, &r14);
	GetCtrlVal (panelHandle, PANEL_Resistance_4, &r23);
	GetCtrlVal (panelHandle, PANEL_Resistance_5, &r24);
	GetCtrlVal (panelHandle, PANEL_Resistance_6, &r34);
	
	
}



void SetQ()
{
	
	SetCtrlVal (panelHandle, PANEL_Capacitor, v1);
	SetCtrlVal (panelHandle, PANEL_Capacitor_2, v2);
	SetCtrlVal (panelHandle, PANEL_Capacitor_3, v3);
	SetCtrlVal (panelHandle, PANEL_Capacitor_4, v4);
	
	SetCtrlVal (panelHandle, PANEL_Voltage, v1);
	SetCtrlVal (panelHandle, PANEL_Voltage_2, v2);
	SetCtrlVal (panelHandle, PANEL_Voltage_3, v3);
	SetCtrlVal (panelHandle, PANEL_Voltage_4, v4);
	
}

void SetDt()
{
	if (r*c1<r*c2)
		dt=r*c1/200;
	else
		dt=r*c2/200;
	
	
	
	
}
 
void UpdateCurrentsAndVoltages()
{
    // Get updated global values
    GetGlobalVal();

    double Rmat[6][4] = {
        {1/r, -1/r, 0, 0},
        {1/r13, 0, -1/r13, 0},
        {1/r14, 0, 0, -1/r14},
        {0, 1/r23, -1/r23, 0},
        {0, 1/r24, 0, -1/r24},
        {0, 0, 1/r34, -1/r34}
    };

    // Define the voltage vector
     double Uvec[4] = {v1, v2, v3, v4};

    // Set the resistance matrix and voltage vector in the UI
    SetTableCellRangeVals(panelHandle, PANEL_Rmat, MakeRect(1, 1, 6, 4), (double*)Rmat, VAL_ROW_MAJOR);
    SetTableCellRangeVals(panelHandle, PANEL_Uvec, MakeRect(1, 1, 4, 1), (double*)Uvec, VAL_ROW_MAJOR);

    // Perform matrix-vector multiplication
    MatrixMul((double*)Rmat, Uvec, 6, 4, 1, Ivec);

    // Update currents
    i = Ivec[0];
    i13 = Ivec[1];
    i14 = Ivec[2];
    i23 = Ivec[3];
    i24 = Ivec[4];
    i34 = Ivec[5];

    // Update charges and voltages for capacitors
    q1 = c1 * v1;
    q2 = c2 * v2;
    q3 = c3 * v3;
    q4 = c4 * v4;

    q1 += (i - i13 - i14) * dt + cu1 * dt;
    q2 += (-i + i23 + i24) * dt + cu2 * dt;
    q3 += (-i13 - i23 + i34) * dt;
    q4 += (-i14 - i24 - i34) * dt;

    v1 = q1 / c1;
    v2 = q2 / c2;
    v3 = q3 / c3;
    v4 = q4 / c4;
	
	Uvec[0]=v1	   ;
	Uvec[1]=v2  ;
	Uvec[2]=v3  ;
	Uvec[3]=v4  ;
	
	SetQ();
    // Update UI controls
   
    SetCtrlVal(panelHandle, PANEL_Current, i);
    SetCtrlVal(panelHandle, PANEL_Current_2, i13);
    SetCtrlVal(panelHandle, PANEL_Current_3, i14);
    SetCtrlVal(panelHandle, PANEL_Current_4, i23);
    SetCtrlVal(panelHandle, PANEL_Current_5, i24);
    SetCtrlVal(panelHandle, PANEL_Current_6, i34);

    // Update the current vector in the UI
    SetTableCellRangeVals(panelHandle, PANEL_Ivec, MakeRect(1, 1, 6, 1), (double*)Ivec, VAL_ROW_MAJOR);
	SetTableCellRangeVals(panelHandle, PANEL_Uvec, MakeRect(1, 1, 4, 1), (double*)Uvec, VAL_ROW_MAJOR); 
	
}


int main (int argc, char *argv[])
{
	if (InitCVIRTE (0, argv, 0) == 0)
		return -1;	/* out of memory */
	if ((panelHandle = LoadPanel (0, "lab2.uir", PANEL)) < 0)
		return -1;
	DisplayPanel (panelHandle);
	RunUserInterface ();
	DiscardPanel (panelHandle);
	
	return 0;
}

int CVICALLBACK QuitCallback (int panel, int control, int event,
							  void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			QuitUserInterface (0);
			break;
	}
	return 0;
}

int CVICALLBACK Go(int panel, int control, int event, void *callbackData, int eventData1, int eventData2)
{
    switch (event)
    {
        case EVENT_COMMIT:
            GetGlobalVal();
			SetDt();
			SetQ();
            q1 = c1 * v1;
            q2 = c2 * v2;
            q3 = c3 * v3;
            q4 = c4 * v4;
			
			
			
            SetCtrlAttribute(panelHandle, PANEL_TIMER, ATTR_INTERVAL, dt);
            SetCtrlAttribute(panelHandle, PANEL_TIMER, ATTR_ENABLED, 1);
            break;
    }
    return 0;
}

int CVICALLBACK TIMER(int panel, int control, int event, void *callbackData, int eventData1, int eventData2)
{
	
    switch (event)
    {
		
	 
        case EVENT_TIMER_TICK:
            UpdateCurrentsAndVoltages();
            SetCtrlVal(panelHandle, PANEL_Time, Time += dt);
            break;
    }
    return 0;
}

void CVICALLBACK ViewParallel (int menuBar, int menuItem, void *callbackData,
							   int panel)
{
	
	
}
