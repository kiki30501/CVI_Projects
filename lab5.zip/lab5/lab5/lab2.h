/**************************************************************************/
/* LabWindows/CVI User Interface Resource (UIR) Include File              */
/*                                                                        */
/* WARNING: Do not add to, delete from, or otherwise modify the contents  */
/*          of this include file.                                         */
/**************************************************************************/

#include <userint.h>

#ifdef __cplusplus
    extern "C" {
#endif

     /* Panels and Controls: */

#define  PANEL                            1
#define  PANEL_QUITBUTTON                 2       /* control type: command, callback function: QuitCallback */
#define  PANEL_Voltage_4                  3       /* control type: numeric, callback function: (none) */
#define  PANEL_Voltage_3                  4       /* control type: numeric, callback function: (none) */
#define  PANEL_Voltage_2                  5       /* control type: numeric, callback function: (none) */
#define  PANEL_Current_in_2               6       /* control type: numeric, callback function: (none) */
#define  PANEL_Capacitance_4              7       /* control type: numeric, callback function: (none) */
#define  PANEL_Capacitance_3              8       /* control type: numeric, callback function: (none) */
#define  PANEL_Capacitance_2              9       /* control type: numeric, callback function: (none) */
#define  PANEL_Capacitor_2                10      /* control type: scale, callback function: (none) */
#define  PANEL_Voltage                    11      /* control type: numeric, callback function: (none) */
#define  PANEL_Current_in                 12      /* control type: numeric, callback function: (none) */
#define  PANEL_Capacitance                13      /* control type: numeric, callback function: (none) */
#define  PANEL_Capacitor                  14      /* control type: scale, callback function: (none) */
#define  PANEL_Resistance_6               15      /* control type: numeric, callback function: (none) */
#define  PANEL_Resistance_5               16      /* control type: numeric, callback function: (none) */
#define  PANEL_Resistance_4               17      /* control type: numeric, callback function: (none) */
#define  PANEL_Resistance_3               18      /* control type: numeric, callback function: (none) */
#define  PANEL_Resistance_2               19      /* control type: numeric, callback function: (none) */
#define  PANEL_Resistance                 20      /* control type: numeric, callback function: (none) */
#define  PANEL_Go                         21      /* control type: command, callback function: Go */
#define  PANEL_Current_6                  22      /* control type: numeric, callback function: (none) */
#define  PANEL_Current_5                  23      /* control type: numeric, callback function: (none) */
#define  PANEL_Current_4                  24      /* control type: numeric, callback function: (none) */
#define  PANEL_Current_3                  25      /* control type: numeric, callback function: (none) */
#define  PANEL_Current_2                  26      /* control type: numeric, callback function: (none) */
#define  PANEL_Current                    27      /* control type: numeric, callback function: (none) */
#define  PANEL_SPLITTER_4                 28      /* control type: splitter, callback function: (none) */
#define  PANEL_SPLITTER_3                 29      /* control type: splitter, callback function: (none) */
#define  PANEL_SPLITTER_6                 30      /* control type: splitter, callback function: (none) */
#define  PANEL_SPLITTER_5                 31      /* control type: splitter, callback function: (none) */
#define  PANEL_SPLITTER_2                 32      /* control type: splitter, callback function: (none) */
#define  PANEL_SPLITTER                   33      /* control type: splitter, callback function: (none) */
#define  PANEL_Time                       34      /* control type: numeric, callback function: (none) */
#define  PANEL_TIMER                      35      /* control type: timer, callback function: TIMER */
#define  PANEL_Capacitor_3                36      /* control type: scale, callback function: (none) */
#define  PANEL_Capacitor_4                37      /* control type: scale, callback function: (none) */
#define  PANEL_Rmat                       38      /* control type: table, callback function: (none) */
#define  PANEL_Ivec                       39      /* control type: table, callback function: (none) */
#define  PANEL_Uvec                       40      /* control type: table, callback function: (none) */


     /* Control Arrays: */

          /* (no control arrays in the resource file) */


     /* Menu Bars, Menus, and Menu Items: */

#define  MENUBAR                          1
#define  MENUBAR_MENU1                    2
#define  MENUBAR_MENU1_ITEM1              3       /* callback function: ShowParalel */

#define  MENUBAR_2                        2
#define  MENUBAR_2_MENU1                  2
#define  MENUBAR_2_MENU1_ITEM1            3       /* callback function: ViewParallel */


     /* Callback Prototypes: */

int  CVICALLBACK Go(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK QuitCallback(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
void CVICALLBACK ShowParalel(int menubar, int menuItem, void *callbackData, int panel);
int  CVICALLBACK TIMER(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
void CVICALLBACK ViewParallel(int menubar, int menuItem, void *callbackData, int panel);


#ifdef __cplusplus
    }
#endif
